	Default-Enabled Ore Distributions

In order to prevent overgeneration of certain ores, this list shows which mods' ores will be used exclusively in the world generation.  Since all these ores are in the Forge Ore Dictionary, these ores are compatible with all mods that support the Ore Dictionary.

* Marble: Chisel 2
* Copper: Thermal Foundation
* Tin: Thermal Foundation
* Silver: Thermal Foundation
* Nickel: ElectriCraft
* Aluminum: ElectriCraft
* Platinum: ElectriCraft

